package es.aad.gianmoenaunidad3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gianmoenaunidad3Application {

	public static void main(String[] args) {
		SpringApplication.run(Gianmoenaunidad3Application.class, args);
	}

}
