package ies.jandula.ejercicio_pag_12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioPag12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
