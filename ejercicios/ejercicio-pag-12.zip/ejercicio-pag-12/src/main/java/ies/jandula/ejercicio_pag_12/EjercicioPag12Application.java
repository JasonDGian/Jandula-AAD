package ies.jandula.ejercicio_pag_12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioPag12Application {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioPag12Application.class, args);
	}

}
